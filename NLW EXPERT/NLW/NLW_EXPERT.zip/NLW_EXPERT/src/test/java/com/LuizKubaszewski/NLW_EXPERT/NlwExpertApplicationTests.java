package com.LuizKubaszewski.NLW_EXPERT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NlwExpertApplicationTests {

	@Test
	void contextLoads() {
	}

}
