package com.LuizKubaszewski.NLW_EXPERT.Modulos.Controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LuizKubaszewski.NLW_EXPERT.Modulos.Estudantes.Dto.VerifyhasCertificationDTO;
import com.LuizKubaszewski.NLW_EXPERT.Modulos.Estudantes.Dto.useCases.VerifyIfHasCertificationUseCases;

@RestController
@RequestMapping("/Estudantes")
public class StudentController {
    @Autowired
    private VerifyIfHasCertificationUseCases VerifyIfHasCertificationUseCases;

    @PostMapping("/verifyifHasCertification")
    public String verifyHasCertification(@RequestBody VerifyhasCertificationDTO verifyhasCertificationDTO){

        var result = this.VerifyIfHasCertificationUseCases.execute(verifyhasCertificationDTO);
        if(result){
            return "Usuário já fez a prova";
        }

        return "Usuário pode fazer a prova";
    }
    
}
