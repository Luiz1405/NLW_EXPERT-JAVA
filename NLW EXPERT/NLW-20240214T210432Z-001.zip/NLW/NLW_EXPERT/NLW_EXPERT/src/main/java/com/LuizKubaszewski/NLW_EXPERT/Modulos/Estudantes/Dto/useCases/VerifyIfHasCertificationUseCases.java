package com.LuizKubaszewski.NLW_EXPERT.Modulos.Estudantes.Dto.useCases;

import org.springframework.stereotype.Service;
import com.LuizKubaszewski.NLW_EXPERT.Modulos.Estudantes.Dto.VerifyhasCertificationDTO;
@Service
public class VerifyIfHasCertificationUseCases {

    public boolean execute(VerifyhasCertificationDTO dto){

        if(dto.getEmail().equals("kubaszewski001@hotmail.com") && dto.getTechnology().equals("JAVA")) {
            return true;
        }
        return false;
    }   
    
    
}   
