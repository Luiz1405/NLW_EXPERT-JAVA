package com.LuizKubaszewski.NLW_EXPERT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NlwExpertApplication {

	public static void main(String[] args) {
		SpringApplication.run(NlwExpertApplication.class, args);
	}

}
